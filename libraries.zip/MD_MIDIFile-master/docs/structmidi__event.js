var structmidi__event =
[
    [ "channel", "structmidi__event.html#ae28dc113b66bc5eb7d38b8bee915d375", null ],
    [ "data", "structmidi__event.html#a1475ad8c61b5dfa4b27941808c71dbd6", null ],
    [ "size", "structmidi__event.html#af270b4ef165f69edf11b065b5ddfbc75", null ],
    [ "track", "structmidi__event.html#a22366b79c95b322c300d91f280ae2a5f", null ]
];