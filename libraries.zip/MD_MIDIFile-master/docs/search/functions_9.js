var searchData=
[
  ['setfilename',['setFilename',['../class_m_d___m_i_d_i_file.html#ac12bbaa6cedc1e973312976cb85b3324',1,'MD_MIDIFile']]],
  ['setmicrosecondperquarternote',['setMicrosecondPerQuarterNote',['../class_m_d___m_i_d_i_file.html#a52b967081cc692b44d2a9ea6ffc9a848',1,'MD_MIDIFile']]],
  ['setmidihandler',['setMidiHandler',['../class_m_d___m_i_d_i_file.html#afe0927aea3ccec475c307f5169c9d073',1,'MD_MIDIFile']]],
  ['setsysexhandler',['setSysexHandler',['../class_m_d___m_i_d_i_file.html#a87b3e2395f01d792b5932317f014ffb0',1,'MD_MIDIFile']]],
  ['settempo',['setTempo',['../class_m_d___m_i_d_i_file.html#a0880b75e2d6780979e57b37021788d4c',1,'MD_MIDIFile']]],
  ['settempoadjust',['setTempoAdjust',['../class_m_d___m_i_d_i_file.html#a5089c6ddc03440fe15ec1f0aa748da46',1,'MD_MIDIFile']]],
  ['setticksperquarternote',['setTicksPerQuarterNote',['../class_m_d___m_i_d_i_file.html#aa8021b6a43e42494392659652628864a',1,'MD_MIDIFile']]],
  ['settimesignature',['setTimeSignature',['../class_m_d___m_i_d_i_file.html#a4901e4e5957aa6d68c6711e2a95b6ef4',1,'MD_MIDIFile']]],
  ['synchtracks',['synchTracks',['../class_m_d___m_i_d_i_file.html#a1291d2bdf7e9d381181c2cfc6dceb494',1,'MD_MIDIFile']]],
  ['synctime',['syncTime',['../class_m_d___m_f_track.html#afebb7f1c3d6d8c940dc7cff851f9e786',1,'MD_MFTrack']]]
];
