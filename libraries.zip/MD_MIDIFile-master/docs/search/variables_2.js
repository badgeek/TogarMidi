var searchData=
[
  ['data',['data',['../structmidi__event.html#a1475ad8c61b5dfa4b27941808c71dbd6',1,'midi_event::data()'],['../structsysex__event.html#ac5482f016131c3d5bec81f107ab031c1',1,'sysex_event::data()']]]
];
