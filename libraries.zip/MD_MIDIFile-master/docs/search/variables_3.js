var searchData=
[
  ['size',['size',['../structmidi__event.html#af270b4ef165f69edf11b065b5ddfbc75',1,'midi_event::size()'],['../structsysex__event.html#ab0e32c5fc8f9bb75c980928170010559',1,'sysex_event::size()']]]
];
