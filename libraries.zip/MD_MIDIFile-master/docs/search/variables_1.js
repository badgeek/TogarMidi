var searchData=
[
  ['channel',['channel',['../structmidi__event.html#ae28dc113b66bc5eb7d38b8bee915d375',1,'midi_event']]]
];
