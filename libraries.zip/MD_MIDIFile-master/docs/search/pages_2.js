var searchData=
[
  ['midi_20beat_20time_20considerations',['MIDI Beat Time Considerations',['../page_timing.html',1,'index']]]
];
