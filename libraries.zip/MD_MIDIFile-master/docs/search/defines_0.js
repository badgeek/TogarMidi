var searchData=
[
  ['buf_5fsize',['BUF_SIZE',['../_m_d___m_i_d_i_helper_8h.html#a33185d2e323592e07367347b20b0b910',1,'MD_MIDIHelper.h']]]
];
