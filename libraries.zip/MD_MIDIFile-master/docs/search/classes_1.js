var searchData=
[
  ['sysex_5fevent',['sysex_event',['../structsysex__event.html',1,'']]]
];
