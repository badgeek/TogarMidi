var structsysex__event =
[
    [ "data", "structsysex__event.html#ac5482f016131c3d5bec81f107ab031c1", null ],
    [ "size", "structsysex__event.html#ab0e32c5fc8f9bb75c980928170010559", null ],
    [ "track", "structsysex__event.html#a053ca2be5e984d886d319967d590ac29", null ]
];