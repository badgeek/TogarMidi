var index =
[
    [ "SMF Format Definition", "page_smf_definition.html", null ],
    [ "MIDI Beat Time Considerations", "page_timing.html", null ],
    [ "Hardware Interface", "page_hardware.html", null ],
    [ "Notes on the Library", "page_library.html", null ]
];