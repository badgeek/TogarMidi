var annotated_dup =
[
    [ "MD_MFTrack", "class_m_d___m_f_track.html", "class_m_d___m_f_track" ],
    [ "MD_MIDIFile", "class_m_d___m_i_d_i_file.html", "class_m_d___m_i_d_i_file" ],
    [ "midi_event", "structmidi__event.html", "structmidi__event" ],
    [ "sysex_event", "structsysex__event.html", "structsysex__event" ]
];