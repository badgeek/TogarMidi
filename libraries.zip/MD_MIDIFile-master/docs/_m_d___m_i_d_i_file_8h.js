var _m_d___m_i_d_i_file_8h =
[
    [ "midi_event", "structmidi__event.html", "structmidi__event" ],
    [ "sysex_event", "structsysex__event.html", "structsysex__event" ],
    [ "MD_MFTrack", "class_m_d___m_f_track.html", "class_m_d___m_f_track" ],
    [ "MD_MIDIFile", "class_m_d___m_i_d_i_file.html", "class_m_d___m_i_d_i_file" ],
    [ "DUMP", "_m_d___m_i_d_i_file_8h.html#a5b4c5e778644ec86274206a1cb510ee4", null ],
    [ "DUMP_DATA", "_m_d___m_i_d_i_file_8h.html#a5f4a9ee8152a0634fa531070c07cc179", null ],
    [ "DUMPS", "_m_d___m_i_d_i_file_8h.html#a74378977b17d56673d339d819054f3ca", null ],
    [ "DUMPX", "_m_d___m_i_d_i_file_8h.html#a86a19a6ebead733b7bee7c594e324ecb", null ],
    [ "MIDI_MAX_TRACKS", "_m_d___m_i_d_i_file_8h.html#aed157e8f945933564e07a26e2516023b", null ],
    [ "SHOW_UNUSED_META", "_m_d___m_i_d_i_file_8h.html#a0365c3c876d5d312b4d86fbd1fefbf54", null ],
    [ "TRACK_PRIORITY", "_m_d___m_i_d_i_file_8h.html#a701b44b0487a21ace4cde40d590c6cd6", null ]
];